/*
  Carlos Pineda Guerrero, abril 2023
*/

package servicio_json;

import com.google.gson.*;

public class ParamModificaUsuario 
{
  Usuario usuario;
}
